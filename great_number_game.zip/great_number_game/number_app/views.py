from django.shortcuts import render, redirect
import random 	               
def index(request):
    if 'value' not in request.session:
        request.session ['value']= random.randint(1,100)
    else:
        request.session ['value']
    print("--"*80)
    print(request.session['value'])
    return render(request,'index.html')

def process(request):
    request.session['number'] = int(request.POST['number'])
    if (request.session['number']>request.session['value']):
        request.session['result'] ='Too High'
    if (request.session['number']<request.session['value']):
        request.session['result'] ='Too Low'
    if (request.session['number']==request.session['value']):
        request.session['result'] = request.session ['value']
    return redirect('/')

