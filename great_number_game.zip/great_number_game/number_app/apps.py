from django.apps import AppConfig


class NumberAppConfig(AppConfig):
    name = 'number_app'
